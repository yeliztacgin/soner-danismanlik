import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { About } from "@/components/About";
import { Services } from "@/components/Services";
import { Testimonials } from "@/components/Testimonials";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";
import { WhatsAppFloat } from "@/components/WhatsAppFloat";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      {
        title:
          "Soner Fal Danışmanlık — Spiritüel Danışmanlık, Kahve Falı, Tarot ve Yıldızname",
      },
      {
        name: "description",
        content:
          "Soner Fal Danışmanlık ile kahve falı, tarot, yıldızname ve mistik danışmanlık hizmetleri. +15.000 mutlu müşteri, %98 memnuniyet. Ankara Çankaya — WhatsApp ile hemen randevu.",
      },
      {
        name: "keywords",
        content:
          "soner fal danışmanlık, kahve falı, tarot falı, yıldızname, fal ankara, çankaya fal, katina aşk falı, çakra açma, yıldız haritası, horoskop",
      },
      { name: "author", content: "Soner Fal Danışmanlık" },
      { name: "robots", content: "index, follow" },
      { property: "og:title", content: "Soner Fal Danışmanlık — Spiritüel Danışmanlık ve Fal Hizmetleri" },
      {
        property: "og:description",
        content:
          "Kahve falı, tarot, yıldızname ve birçok mistik danışmanlık hizmeti. Ankara/Çankaya.",
      },
      { property: "og:type", content: "website" },
      { property: "og:locale", content: "tr_TR" },
      { property: "og:url", content: "https://medyumsoner.com.tr" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Soner Fal Danışmanlık — Spiritüel Danışmanlık" },
      {
        name: "twitter:description",
        content: "Kahve falı, tarot, yıldızname ve mistik danışmanlık.",
      },
    ],
    links: [{ rel: "canonical", href: "https://medyumsoner.com.tr/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "LocalBusiness",
          name: "Soner Fal Danışmanlık",
          image: "https://medyumsoner.com.tr/og.jpg",
          "@id": "https://medyumsoner.com.tr",
          url: "https://medyumsoner.com.tr",
          telephone: "+905456923727",
          priceRange: "₺₺",
          address: {
            "@type": "PostalAddress",
            streetAddress: "Kültür, Meşrutiyet Cd. 38/6",
            addressLocality: "Çankaya",
            addressRegion: "Ankara",
            postalCode: "06590",
            addressCountry: "TR",
          },
          openingHours: "Mo-Su 09:00-22:00",
          aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: "4.9",
            reviewCount: "15000",
          },
          description:
            "Kahve falı, tarot, yıldızname ve mistik danışmanlık hizmetleri.",
        }),
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="relative">
      <Navbar />
      <Hero />
      <About />
      <Services />
      <Testimonials />
      <Contact />
      <Footer />
      <WhatsAppFloat />
    </main>
  );
}
