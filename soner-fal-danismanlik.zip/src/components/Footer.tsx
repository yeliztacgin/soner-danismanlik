import { Sparkles } from "lucide-react";

export function Footer() {
  return (
    <footer className="border-t border-gold/20 py-10 mt-10">
      <div className="container mx-auto px-5 flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-gold" />
          <span className="font-display text-lg text-gradient-gold">
            Soner Fal Danışmanlık
          </span>
        </div>
        <p className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} medyumsoner.com.tr — Tüm hakları saklıdır.
        </p>
      </div>
    </footer>
  );
}
