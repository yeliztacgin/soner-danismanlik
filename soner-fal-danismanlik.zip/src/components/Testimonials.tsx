import { Quote, Star, Users, ThumbsUp } from "lucide-react";

const testimonials = [
  {
    name: "İklim M.",
    text: "Teşekkürler Soner Bey, harika bir fal bakımıydı. Geçmişimizi, geleceğimizi ve şu anki durumu inanılmaz analiz etti. İnanılmaz şaşırdığım noktalar oldu, mutlaka tavsiye ediyorum.",
  },
  {
    name: "Aslıhan A.",
    text: "Hayatımın falcısı! Her dediği çıkan ve bilen bir kişi daha görmedim. Çok tatlı ve samimi biri Soner Bey, ben çok severek geliyorum.",
  },
  {
    name: "Gizem S.",
    text: "Çok tatlı bir yer, Soner abi de bir o kadar tatlı bir insan ve ciddi şekilde her şeyi bildi. Düşünmeden tercih edebilirsiniz, çok beğendim.",
  },
];

export function Testimonials() {
  return (
    <section id="yorumlar" className="py-20 md:py-28 relative">
      <div className="container mx-auto px-5">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="text-xs tracking-[0.3em] uppercase text-gold mb-4">
            Referanslar
          </div>
          <h2 className="font-display text-3xl md:text-5xl font-semibold mb-5">
            Müşterilerim <span className="text-gradient-gold">Ne Diyor?</span>
          </h2>
          <div className="gold-divider mb-5 max-w-[120px] mx-auto" />
        </div>

        <div className="grid sm:grid-cols-2 gap-6 max-w-3xl mx-auto mb-14">
          <div className="glass-card rounded-2xl p-8 text-center">
            <Users className="w-8 h-8 text-gold mx-auto mb-3" />
            <div className="font-display text-4xl md:text-5xl text-gradient-gold font-semibold mb-1">
              +15.000
            </div>
            <div className="text-sm text-muted-foreground tracking-wider uppercase">
              Mutlu Müşteri
            </div>
          </div>
          <div className="glass-card rounded-2xl p-8 text-center">
            <ThumbsUp className="w-8 h-8 text-gold mx-auto mb-3" />
            <div className="font-display text-4xl md:text-5xl text-gradient-gold font-semibold mb-1">
              %98
            </div>
            <div className="text-sm text-muted-foreground tracking-wider uppercase">
              Müşteri Memnuniyeti
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <article
              key={t.name}
              className="glass-card rounded-2xl p-7 relative hover:border-gold/40 transition-colors"
            >
              <Quote className="w-10 h-10 text-gold/30 mb-4" />
              <div className="flex gap-1 mb-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-gold fill-gold" />
                ))}
              </div>
              <p className="text-sm md:text-base text-foreground/90 leading-relaxed mb-6 italic">
                “{t.text}”
              </p>
              <div className="flex items-center gap-3 pt-4 border-t border-gold/20">
                <div className="w-10 h-10 rounded-full bg-gradient-gold flex items-center justify-center text-primary-foreground font-semibold">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <div className="font-display text-lg text-gold">{t.name}</div>
                  <div className="text-xs text-muted-foreground">
                    Doğrulanmış Müşteri
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
