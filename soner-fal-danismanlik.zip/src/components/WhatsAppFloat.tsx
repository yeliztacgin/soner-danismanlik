import whatsappLogo from "@/assets/whatsapp.png";

export function WhatsAppFloat() {
  return (
    <a
      href="https://api.whatsapp.com/send/?phone=905456923727&text&type=phone_number&app_absent=0"
      target="_blank"
      rel="noopener noreferrer"
      aria-label="WhatsApp ile iletişime geç"
      className="fixed bottom-6 right-6 z-50 flex items-center justify-center w-14 h-14 md:w-16 md:h-16 rounded-2xl shadow-glow animate-glow-pulse hover:scale-110 transition-transform"
    >
      <img
        src={whatsappLogo}
        alt="WhatsApp"
        width={64}
        height={64}
        className="w-full h-full object-contain"
      />
    </a>
  );
}
