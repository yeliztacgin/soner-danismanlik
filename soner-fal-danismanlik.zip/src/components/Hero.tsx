import { MessageCircle, Phone, Sparkles } from "lucide-react";
import heroImg from "@/assets/hero.jpg";

export function Hero() {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-24 pb-16"
    >
      <div className="absolute inset-0 -z-10">
        <img
          src={heroImg}
          alt="Mistik tarot kartları, kristal küre ve altın süslemeler"
          width={1536}
          height={1024}
          className="w-full h-full object-cover opacity-35"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/80 to-background" />
      </div>

      <div className="container mx-auto px-5 text-center max-w-4xl">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-card mb-6 animate-fade-up">
          <Sparkles className="w-4 h-4 text-gold" />
          <span className="text-xs md:text-sm tracking-wider uppercase text-gold/90">
            Spiritüel Danışmanlık
          </span>
        </div>

        <h1
          className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-semibold leading-[1.05] mb-6 animate-fade-up"
          style={{ animationDelay: "0.1s" }}
        >
          <span className="text-foreground">Soner Fal Danışmanlık ile </span>
          <span className="text-gradient-gold">Spiritüel Danışmanlık</span>
          <span className="text-foreground"> ve Fal Hizmetleri</span>
        </h1>

        <p
          className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed animate-fade-up"
          style={{ animationDelay: "0.25s" }}
        >
          Kahve falı, tarot, yıldızname ve birçok mistik danışmanlık hizmeti.
          Yılların tecrübesi ve binlerce mutlu müşteriyle yanınızdayız.
        </p>

        <div
          className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-up"
          style={{ animationDelay: "0.4s" }}
        >
          <a
            href="https://api.whatsapp.com/send/?phone=905456923727&text&type=phone_number&app_absent=0"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-gradient-gold text-primary-foreground font-semibold shadow-gold hover:scale-105 transition-transform"
          >
            <MessageCircle className="w-5 h-5" />
            WhatsApp İletişim
          </a>
          <a
            href="tel:+905456923727"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full border border-gold/50 text-gold hover:bg-gold/10 transition-colors"
          >
            <Phone className="w-5 h-5" />
            Hemen Ara
          </a>
        </div>

        <div
          className="mt-14 flex flex-wrap items-center justify-center gap-8 text-center animate-fade-up"
          style={{ animationDelay: "0.55s" }}
        >
          <div>
            <div className="font-display text-3xl md:text-4xl text-gradient-gold font-semibold">
              +15.000
            </div>
            <div className="text-xs md:text-sm text-muted-foreground tracking-wider uppercase">
              Mutlu Müşteri
            </div>
          </div>
          <div className="h-10 w-px bg-gold/30" />
          <div>
            <div className="font-display text-3xl md:text-4xl text-gradient-gold font-semibold">
              %98
            </div>
            <div className="text-xs md:text-sm text-muted-foreground tracking-wider uppercase">
              Memnuniyet
            </div>
          </div>
          <div className="h-10 w-px bg-gold/30 hidden sm:block" />
          <div>
            <div className="font-display text-3xl md:text-4xl text-gradient-gold font-semibold">
              15+
            </div>
            <div className="text-xs md:text-sm text-muted-foreground tracking-wider uppercase">
              Yıl Tecrübe
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
