import { useEffect, useState } from "react";
import { Menu, X, Sparkles } from "lucide-react";

const links = [
  { href: "#hakkimda", label: "Hakkımda" },
  { href: "#hizmetlerim", label: "Hizmetlerim" },
  { href: "#yorumlar", label: "Müşterilerim Ne Diyor?" },
  { href: "#iletisim", label: "İletişim" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-background/85 backdrop-blur-md border-b border-gold/20 py-3"
          : "bg-transparent py-5"
      }`}
    >
      <nav className="container mx-auto px-5 flex items-center justify-between">
        <a href="#hero" className="flex items-center gap-2 group">
          <Sparkles className="w-5 h-5 text-gold transition-transform group-hover:rotate-12" />
          <span className="font-display text-xl md:text-2xl font-semibold text-gradient-gold">
            Soner Fal Danışmanlık
          </span>
        </a>

        <ul className="hidden lg:flex items-center gap-8">
          {links.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="text-sm text-foreground/80 hover:text-gold transition-colors relative after:absolute after:left-0 after:-bottom-1 after:h-px after:w-0 after:bg-gold after:transition-all hover:after:w-full"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        <a
          href="https://api.whatsapp.com/send/?phone=905456923727&text&type=phone_number&app_absent=0"
          target="_blank"
          rel="noopener noreferrer"
          className="hidden lg:inline-flex items-center px-5 py-2 rounded-full bg-gradient-gold text-primary-foreground text-sm font-semibold shadow-gold hover:scale-105 transition-transform"
        >
          WhatsApp
        </a>

        <button
          aria-label="Menüyü aç/kapat"
          onClick={() => setOpen((v) => !v)}
          className="lg:hidden text-gold p-2"
        >
          {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </nav>

      {open && (
        <div className="lg:hidden border-t border-gold/20 bg-background/95 backdrop-blur-md animate-fade-up">
          <ul className="container mx-auto px-5 py-6 flex flex-col gap-4">
            {links.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="block py-2 text-base text-foreground/90 hover:text-gold transition-colors"
                >
                  {l.label}
                </a>
              </li>
            ))}
            <li>
              <a
                href="https://api.whatsapp.com/send/?phone=905456923727&text&type=phone_number&app_absent=0"
                target="_blank"
                rel="noopener noreferrer"
                className="block text-center mt-2 px-5 py-3 rounded-full bg-gradient-gold text-primary-foreground font-semibold"
              >
                WhatsApp İletişim
              </a>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
}
