import { Phone, MapPin, MessageCircle, Clock } from "lucide-react";
import whatsappLogo from "@/assets/whatsapp.png";

export function Contact() {
  return (
    <section id="iletisim" className="py-20 md:py-28 relative">
      <div className="container mx-auto px-5">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="text-xs tracking-[0.3em] uppercase text-gold mb-4">
            İletişim
          </div>
          <h2 className="font-display text-3xl md:text-5xl font-semibold mb-5">
            Bize <span className="text-gradient-gold">Ulaşın</span>
          </h2>
          <div className="gold-divider mb-5 max-w-[120px] mx-auto" />
          <p className="text-muted-foreground">
            Randevu almak veya sorularınız için bizimle iletişime geçin.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          <div className="space-y-5">
            <a
              href="tel:+905456923727"
              className="glass-card rounded-2xl p-6 flex items-start gap-4 hover:border-gold/50 transition-colors group"
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-gold flex items-center justify-center shrink-0 shadow-gold">
                <Phone className="w-5 h-5 text-primary-foreground" />
              </div>
              <div className="flex-1">
                <div className="text-xs tracking-wider uppercase text-muted-foreground mb-1">
                  Telefon
                </div>
                <div className="font-display text-xl text-foreground group-hover:text-gold transition-colors">
                  +90 545 692 37 27
                </div>
                <div className="text-xs text-gold mt-1">Aramak için tıklayın →</div>
              </div>
            </a>

            <a
              href="https://api.whatsapp.com/send/?phone=905456923727&text&type=phone_number&app_absent=0"
              target="_blank"
              rel="noopener noreferrer"
              className="glass-card rounded-2xl p-6 flex items-start gap-4 hover:border-gold/50 transition-colors group"
            >
              <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 shadow-glow overflow-hidden">
                <img src={whatsappLogo} alt="WhatsApp" width={48} height={48} className="w-full h-full object-contain" />
              </div>
              <div className="flex-1">
                <div className="text-xs tracking-wider uppercase text-muted-foreground mb-1">
                  WhatsApp
                </div>
                <div className="font-display text-xl text-foreground group-hover:text-gold transition-colors">
                  Mesaj Gönder
                </div>
                <div className="text-xs text-gold mt-1">Hızlı yanıt alın →</div>
              </div>
            </a>

            <div className="glass-card rounded-2xl p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-gold flex items-center justify-center shrink-0 shadow-gold">
                <MapPin className="w-5 h-5 text-primary-foreground" />
              </div>
              <div className="flex-1">
                <div className="text-xs tracking-wider uppercase text-muted-foreground mb-1">
                  Adres
                </div>
                <div className="text-base md:text-lg text-foreground leading-relaxed">
                  Kültür, Meşrutiyet Cd. 38/6,<br />
                  06590 Çankaya / Ankara
                </div>
              </div>
            </div>

            <div className="glass-card rounded-2xl p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-gold flex items-center justify-center shrink-0 shadow-gold">
                <Clock className="w-5 h-5 text-primary-foreground" />
              </div>
              <div className="flex-1">
                <div className="text-xs tracking-wider uppercase text-muted-foreground mb-1">
                  Çalışma Saatleri
                </div>
                <div className="text-base text-foreground">
                  Her gün 09:00 – 22:00
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <a
                href="tel:+905456923727"
                className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full border border-gold/50 text-gold hover:bg-gold/10 transition-colors"
              >
                <Phone className="w-4 h-4" /> Hemen Ara
              </a>
              <a
                href="https://api.whatsapp.com/send/?phone=905456923727&text&type=phone_number&app_absent=0"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-gradient-gold text-primary-foreground font-semibold shadow-gold hover:scale-105 transition-transform"
              >
                <MessageCircle className="w-4 h-4" /> WhatsApp
              </a>
            </div>
          </div>

          <div className="rounded-2xl overflow-hidden border border-gold/30 shadow-mystic min-h-[420px]">
            <iframe
              title="Soner Fal Danışmanlık — Konum"
              src="https://www.google.com/maps?q=K%C3%BClt%C3%BCr,%20Me%C5%9Frutiyet%20Cd.%2038%2F6,%2006590%20%C3%87ankaya%2FAnkara&output=embed"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="w-full h-full min-h-[420px] border-0"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
