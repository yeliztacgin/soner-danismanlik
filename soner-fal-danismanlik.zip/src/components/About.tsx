import { Star } from "lucide-react";
import aboutImg from "@/assets/about.jpg";

export function About() {
  return (
    <section id="hakkimda" className="py-20 md:py-28 relative">
      <div className="container mx-auto px-5">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <div className="absolute -inset-4 bg-gradient-gold opacity-20 blur-2xl rounded-3xl" />
            <div className="relative rounded-2xl overflow-hidden border border-gold/30 shadow-mystic">
              <img
                src={aboutImg}
                alt="Soner Fal Danışmanlık — spiritüel danışman"
                width={1024}
                height={1024}
                loading="lazy"
                className="w-full h-auto object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 hidden md:flex glass-card rounded-xl px-5 py-4 items-center gap-3">
              <Star className="w-6 h-6 text-gold fill-gold" />
              <div>
                <div className="text-xs text-muted-foreground">Güvenilir</div>
                <div className="font-display text-lg text-gold">15+ Yıl</div>
              </div>
            </div>
          </div>

          <div>
            <div className="text-xs tracking-[0.3em] uppercase text-gold mb-4">
              Hakkımda
            </div>
            <h2 className="font-display text-3xl md:text-5xl font-semibold mb-6 leading-tight">
              Sezgilerin <span className="text-gradient-gold">Sırlı Dünyasına</span> Hoş Geldiniz
            </h2>
            <div className="gold-divider mb-6 max-w-[120px]" />
            <p className="text-muted-foreground leading-relaxed mb-4">
              Yıllardır binlerce kişiye yol gösteren Soner Fal Danışmanlık, kahve falı,
              tarot, yıldızname ve birçok mistik alanda derin tecrübeye sahip.
              Her seansında samimiyet, gizlilik ve doğrulukla danışanlarına
              rehberlik eder.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Geçmişin izlerini, şu anın gerçeğini ve geleceğin işaretlerini
              okuyarak hayatınıza ışık tutar. Sıcak, güvenilir ve sonuç odaklı
              danışmanlık için doğru adrestesiniz.
            </p>

            <div className="grid grid-cols-2 gap-4">
              {[
                { t: "Gizli & Güvenli", d: "Tüm görüşmeler tamamen mahremdir." },
                { t: "Birebir Seans", d: "Size özel, tam odaklanma." },
                { t: "Hızlı Geri Dönüş", d: "WhatsApp üzerinden anında." },
                { t: "Uzun Tecrübe", d: "Yılların verdiği derin sezgi." },
              ].map((f) => (
                <div
                  key={f.t}
                  className="glass-card rounded-xl p-4 hover:border-gold/40 transition-colors"
                >
                  <div className="font-display text-lg text-gold mb-1">
                    {f.t}
                  </div>
                  <div className="text-xs text-muted-foreground">{f.d}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
