import {
  Coffee,
  Sparkles,
  Stars,
  Spade,
  Brain,
  Flame,
  Droplets,
  Globe,
  Heart,
  Map,
  Sun,
  Eye,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

type Service = { icon: LucideIcon; title: string; desc: string };

const services: Service[] = [
  {
    icon: Coffee,
    title: "Kahve Falı",
    desc: "Fincanın derinliklerinde geçmişin, şimdinin ve geleceğin sırlarını okuyoruz.",
  },
  {
    icon: Sparkles,
    title: "Tarot",
    desc: "Tarot kartlarının evrensel sembolleriyle yolunuza ışık tutuyoruz.",
  },
  {
    icon: Stars,
    title: "Yıldızname",
    desc: "Doğum bilgilerinize özel hazırlanan kadim yıldızname analizleri.",
  },
  {
    icon: Spade,
    title: "İskambil Falı",
    desc: "İskambil destesiyle hayatınızdaki olayları ve fırsatları okuyoruz.",
  },
  {
    icon: Brain,
    title: "Zihin Okuma",
    desc: "Düşüncelerinizin arka planındaki blokajları ve gerçek niyetleri keşfedin.",
  },
  {
    icon: Eye,
    title: "Çakra Açma",
    desc: "Enerji bedeninizdeki tıkanıklıkları açarak içsel dengeyi geri kazanın.",
  },
  {
    icon: Droplets,
    title: "Su Falı",
    desc: "Suyun saf enerjisiyle berrak ve detaylı geleceğe dair işaretler.",
  },
  {
    icon: Flame,
    title: "Ateş Falı",
    desc: "Alevlerin dilinden tutkuları, dönüşümleri ve önemli haberleri okuyoruz.",
  },
  {
    icon: Globe,
    title: "Küre Falı",
    desc: "Kristal kürede yansıyan görüntülerle derin sezgisel okuma.",
  },
  {
    icon: Heart,
    title: "Katina Aşk Falı",
    desc: "Aşk hayatınızdaki dengeleri, sevgilinin niyetini netlikle ortaya koyar.",
  },
  {
    icon: Map,
    title: "Yıldız Haritası",
    desc: "Doğum anınızın gökyüzünü çıkararak karakter ve kader analizini yapıyoruz.",
  },
  {
    icon: Sun,
    title: "Horoskop",
    desc: "Burcunuza özel günlük, haftalık ve yıllık enerji yorumları.",
  },
];

export function Services() {
  return (
    <section id="hizmetlerim" className="py-20 md:py-28 relative">
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-transparent via-secondary/20 to-transparent" />
      <div className="container mx-auto px-5">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="text-xs tracking-[0.3em] uppercase text-gold mb-4">
            Hizmetlerim
          </div>
          <h2 className="font-display text-3xl md:text-5xl font-semibold mb-5">
            Size Özel <span className="text-gradient-gold">Mistik Danışmanlık</span>
          </h2>
          <div className="gold-divider mb-5 max-w-[120px] mx-auto" />
          <p className="text-muted-foreground">
            Geleneksel ve modern mistik yöntemlerle hayatınızın her alanında yol
            gösterici seanslar.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {services.map((s, i) => {
            const Icon = s.icon;
            return (
              <div
                key={s.title}
                className="group glass-card rounded-2xl p-6 hover:border-gold/50 hover:-translate-y-1 transition-all duration-300"
                style={{ animationDelay: `${i * 0.05}s` }}
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-gold flex items-center justify-center mb-5 shadow-gold group-hover:scale-110 transition-transform">
                  <Icon className="w-6 h-6 text-primary-foreground" />
                </div>
                <h3 className="font-display text-xl text-foreground mb-2">
                  {s.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {s.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
